package com.example.albumart;

import com.google.gson.annotations.SerializedName;

public class Post {
    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public String getUrl() {
        return url;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getThumbnilImageUrl() {
        return thumbnilImageUrl;
    }

    private String title;
   private String artist;
   private String url;

   @SerializedName("image")
   private String imageUrl;

   @SerializedName("thumbnail_image")
   private String thumbnilImageUrl;
}
